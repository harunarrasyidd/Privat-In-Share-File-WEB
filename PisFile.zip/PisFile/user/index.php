<?php
require_once '../helper/connection.php'; // Include your database connection code

$searchKeyword = "";
$result = null;

// Handle search form submission
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['search'])) {
    $searchKeyword = mysqli_real_escape_string($connection, $_GET['search']);

    // Perform search in input_file table
    $query = "SELECT * FROM input_file WHERE 
                Lihat LIKE '%$searchKeyword%' OR 
                Dari LIKE '%$searchKeyword%' OR 
                Kepada LIKE '%$searchKeyword%' OR 
                File LIKE '%$searchKeyword%' OR 
                Status LIKE '%$searchKeyword%'";
    $result = mysqli_query($connection, $query);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>Input Arsip &mdash; POLDA JATENG</title>

    <!-- General CSS Files -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <!-- CSS Libraries -->
    <link rel="stylesheet" href="/ingfoloker/assets/modules/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="/ingfoloker/assets/modules/summernote/summernote-bs4.css">
    <link rel="stylesheet" href="/ingfoloker/assets/modules/owlcarousel2/dist/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="/PisFile/assets/modules/owlcarousel2/dist/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="/PisFile/assets/modules/datatables/datatables.min.css">
    <link rel="stylesheet"
        href="/PisFile/assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="/PisFile/assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">
    <link rel="stylesheet" href="/PisFile/assets/modules/izitoast/css/iziToast.min.css">

    <!-- Template CSS -->
    <link rel="stylesheet" href="/PisFile/assets/css/style.css">
    <link rel="stylesheet" href="/PisFile/assets/css/components.css">
</head>

<body>
    <div id="app">
        <div class="main-wrapper main-wrapper-1">
            <?php
            require_once '../layout/_header.php';
            require_once '../layout/_sidenav.php';
            ?>
            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-header">
                        <h1>Dashboard User</h1>
                    </div>
                    <div class="column">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                                <a href="../user/input/index.php" class="card card-statistic-1">
                                    <div class="card-icon bg-primary">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                    <div class="card-wrap">
                                        <div class="card-header">
                                            <h4>Input File</h4>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                                <a href="../user/view/index.php" class="card card-statistic-1">
                                    <div class="card-icon bg-danger">
                                        <i class="fas fa-file-alt"></i>
                                    </div>
                                    <div class="card-wrap">
                                        <div class="card-header">
                                            <h4>View File</h4>
                                            <div class="card-body">
                                                <!-- Your card body content -->
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php
                    require_once '../layout/_bottom.php';
                    ?>
                </section>
            </div>
        </div>
    </div>

    <?php
    // Close the database connection
    mysqli_close($connection);
    ?>
</body>

</html>