<?php
require_once '../../helper/connection.php';
require_once '../../helper/auth.php';


  $searchKeyword = isset($_GET['search']) ? $_GET['search'] : '';
  $query = "SELECT * FROM input_file WHERE file LIKE '%$searchKeyword%'";
  $result = mysqli_query($connection, $query);
  if (!$result) {
    echo mysqli_error($connection); 
  }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Arsip &mdash; POLDA JATENG</title>

  <!-- General CSS Files -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

  <!-- CSS Libraries -->
  <link rel="stylesheet" href="/PisFile/assets/modules/jqvmap/dist/jqvmap.min.css">
  <link rel="stylesheet" href="/PisFile/assets/modules/summernote/summernote-bs4.css">
  <link rel="stylesheet" href="/PisFile/assets/modules/owlcarousel2/dist/assets/owl.carousel.min.css">
  <link rel="stylesheet" href="/PisFile/assets/modules/owlcarousel2/dist/assets/owl.theme.default.min.css">
  <link rel="stylesheet" href="/PisFile/assets/modules/datatables/datatables.min.css">
  <link rel="stylesheet" href="/PisFile/assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="/PisFile/assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">
  <link rel="stylesheet" href="/PisFile/assets/modules/izitoast/css/iziToast.min.css">

  <!-- Template CSS -->
  <link rel="stylesheet" href="/PisFile/assets/css/style.css">
  <link rel="stylesheet" href="/PisFile/assets/css/components.css">
</head>

<body>
  <div id="app">
    <?php
    require_once '../layout/_header.php';
    require_once '../layout/_sidenav.php';
    ?>

    <!-- View Arsip Section -->
    <div class="main-wrapper main-wrapper-1">
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1>View Arsip</h1>
          </div>
          <div class="column">
            <h2>Search Results</h2>
            <form action=""method="get">
              <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Enter keyword" name="search" value="<?php echo $searchKeyword; ?>">
                <div class="input-group-append">
                  <button class="btn btn-primary" type="submit">Search</button>
                </div>
              </div>
            </form>
            <div class="table-responsive">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th>NO</th>
                    <th>Tanggal</th>
                    <th>Nomor</th>
                    <th>Perihal</th>
                    <th>Dari</th>
                    <th>Kepada</th>
                    <th>File</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $no =1;
                  while ($data = mysqli_fetch_assoc($result)) : ?>
                      <tr>
                        <td> <?=$no ?> </td>
                        <td> <?=$data["tanggal"] ?> </td>
                        <td> <?=$data["nomor"] ?> </td>
                        <td> <?=$data["perihal"] ?> </td>
                        <td> <?=$data["dari"] ?> </td>
                        <td> <?=$data["kepada"] ?> </td>
                        <td> <?=$data["file"] ?> </td>
                        <td> <?=$data["status"] ?> </td>

                      <tr>

                  <?php 
                  $no++;
                  endwhile; ?>

                </tbody>
              </table>
            </div>
            <?php
            require_once '../layout/_bottom.php';
            ?>
            <!-- Your view arsip content goes here -->
          </div>
        </section>
      </div>
    </div>
  </div>

  <?php
  // Close the database connection
  mysqli_close($connection);
  ?>

</body>

</html>
