<?php
require_once '../../helper/connection.php';
require_once '../../helper/auth.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Arsip &mdash; POLDA JATENG</title>

    <!-- General CSS Files -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <!-- Template CSS -->
    <link rel="stylesheet" href="/PisFile/assets/css/style.css">
    <link rel="stylesheet" href="/PisFile/assets/css/components.css">
</head>

<body>
    <div id="app">
        <?php
        require_once '../layout/_header.php';
        require_once '../layout/_sidenav.php';
        ?>
        <div class="main-wrapper main-wrapper-1">
            <div class="main-content">
                <section class="section">
                    <div class="section-header">
                        <h1>Input Arsip</h1>
                    </div>
                    <div class="column">
                        <!-- Div untuk menampilkan notifikasi -->
                        <div id="notification"></div>

                        <form action="simpan_data.php" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="tanggal">Tanggal:</label>
                                <input type="date" name="tanggal" class="form-control" required><br>
                            </div>

                            <div class="form-group">
                                <label for="nomor">Nomor:</label>
                                <input type="number" name="nomor" class="form-control" required><br>
                            </div>

                            <div class="form-group">
                                <label for="perihal">Perihal:</label>
                                <input type="text" name="perihal" class="form-control" required><br>
                            </div>

                            <div class="form-group">
                                <label for="dari">Dari:</label>
                                <input type="text" name="dari" class="form-control" required><br>
                            </div>

                            <div class="form-group">
                                <label for="kepada">Kepada:</label>
                                <input type="text" name="kepada" class="form-control" required><br>
                            </div>

                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" name="email" class="form-control" required><br>
                            </div>

                            <div class="form-group">
                                <label for="file">Upload Gambar:</label>
                                <input type="file" name="file" class="form-control" required><br>
                            </div>

                            <input type="hidden" name="status" value="PENDING">

                            <input type="submit" value="Submit">
                        </form>
                        <?php
                        require_once '../layout/_bottom.php';
                        ?>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha384-tsQFqpEReu7ZLhBV2VZlAu7zcOV+rXbYlF2cqB8txI/8aZajjp4Bqd+V6D5IgvKT" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>

    <!-- Script untuk menampilkan notifikasi -->
    <script>
    // Fungsi untuk menampilkan notifikasi
    function showNotification(message, type) {
        const notificationDiv = document.getElementById('notification');
        // Buat elemen notifikasi baru
        const alertDiv = document.createElement('div');
        alertDiv.classList.add('alert', `alert-${type}`, 'alert-dismissible', 'fade', 'show');
        alertDiv.setAttribute('role', 'alert');
        alertDiv.innerHTML = `
                ${message}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            `;
        // Tambahkan elemen notifikasi ke dalam elemen notifikasi yang sudah ada
        notificationDiv.appendChild(alertDiv);
    }

    // Ambil parameter dari URL untuk menentukan apakah notifikasi harus ditampilkan
    const urlParams = new URLSearchParams(window.location.search);
    const status = urlParams.get('status');

    // Jika status adalah 'success', tampilkan notifikasi sukses
    if (status === 'success') {
        showNotification('Data berhasil disimpan.', 'success');
    }
    // Jika status adalah 'error', tampilkan notifikasi error
    else if (status === 'error') {
        showNotification('Terjadi kesalahan saat menyimpan data.', 'danger');
    }
    </script>
</body>

</html>