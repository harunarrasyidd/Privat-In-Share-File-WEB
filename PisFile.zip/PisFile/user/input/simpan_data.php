<?php
// proses_inputan.php

// pastikan path ke PHPMailer benar
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once '../../helper/connection.php';
require_once '../../helper/auth.php';

$tanggal = $_POST['tanggal'];
$nomor = $_POST['nomor'];
$perihal = $_POST['perihal'];
$dari = $_POST['dari'];
$kepada = $_POST['kepada'];
$email = $_POST['email'];
$target_dir = "path/to/your/upload/directory/";
$file_name = basename($_FILES["file"]["name"]);
$target_file = $target_dir . $file_name;
$status = $_POST['status']; 

// Lakukan kueri SQL INSERT
$sql = "INSERT INTO input_file (tanggal, nomor, perihal, dari, kepada, email, file, status) 
        VALUES ('$tanggal', $nomor, '$perihal', '$dari', '$kepada', '$email', '$file_name', '$status')";

if (file_exists($target_file)) {
    echo "Maaf, file sudah ada.";
} else {
    if ($_FILES["file"]["size"] > 500000) {
        echo "Maaf, file terlalu besar.";
    } else {
        // Pindahkan file ke direktori tujuan
        if (is_dir($target_dir)) {
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
                // Eksekusi kueri
                $result = mysqli_query($connection, $sql);
                if ($result) {
                    // Kirim email
                    $mail = new PHPMailer(true);
                    try {
                        //Server settings
                        $mail->isSMTP();
                        $mail->Host       = 'smtp.gmail.com';
                        $mail->SMTPAuth   = true;
                        $mail->Username   = 'marcothephoenix769@gmail.com'; // Ganti dengan alamat Gmail Anda
                        $mail->Password   = 'btyo gbfm yyhy xexo'; // Ganti dengan kata sandi Gmail Anda
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                        $mail->Port       = 587;


                        //Recipients
                        $mail->setFrom('marcothephoenix769@gmail.com', 'Marco'); // Ganti dengan alamat email dan nama Anda
                        $mail->addAddress($email);

                        //Attachments
                        $mail->addAttachment($target_file, $file_name);

                        //Content
                        $mail->isHTML(true);
                        $mail->Subject = $perihal;
                        $mail->Body    = 'File terlampir: ' . $file_name;

                        $mail->send();
                        echo "<script>alert('Data dan file berhasil disimpan. Email berhasil dikirim.'); window.location.href = 'index.php';</script>";
                    } catch (Exception $e) {
                        echo "Email tidak dapat dikirim. Pesan Kesalahan: {$mail->ErrorInfo}";
                    }
                } else {
                    echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
                }
            } else {
                echo "Maaf, terjadi kesalahan saat mengunggah file.";
            }
        } else {
            echo "Maaf, direktori tujuan tidak ditemukan.";
        }
    }
}

// Tutup koneksi
mysqli_close($connection);
?>
