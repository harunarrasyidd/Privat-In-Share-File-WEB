-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2024 at 02:35 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pisfile`
--

-- --------------------------------------------------------

--
-- Table structure for table `input_file`
--

CREATE TABLE `input_file` (
  `kode_file` int(20) NOT NULL,
  `tanggal` date NOT NULL,
  `nomor` int(11) NOT NULL,
  `perihal` varchar(50) NOT NULL,
  `dari` varchar(50) NOT NULL,
  `kepada` varchar(50) NOT NULL,
  `file` varchar(100) NOT NULL,
  `status` enum('PENDING','ACCEPTED','REJECTED') DEFAULT 'PENDING',
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `input_file`
--

INSERT INTO `input_file` (`kode_file`, `tanggal`, `nomor`, `perihal`, `dari`, `kepada`, `file`, `status`, `email`) VALUES
(33, '2024-01-27', 324, '34', '432', '234', 'Surat Tanda Terima PT NIAGA JAYA.pdf', 'ACCEPTED', NULL),
(34, '2222-02-02', 2134, '1234', 'syifa', 'ayu', 'DATA PERMANFAATAN TANAH PEKARANGAN RT.docx', 'ACCEPTED', NULL),
(35, '2024-01-25', 3223, '761', 'yesika', 'dyah', 'Surat Tanda Terima PT NIAGA JAYA.pdf', '', NULL),
(36, '2024-01-26', 6556, '9090', 'chika', 'yee', 'Surat Tanda Terima PT NIAGA JAYA.docx', '', NULL),
(37, '2024-01-31', 3237, '2323', 'pipa', 'sisi', 'Iuran_Sosial_Dawis_Sakura_17[1].docx', '', NULL),
(38, '2024-01-24', 8989, 'pengajuan berkas', 'selva', 'nia', 'DATA PERMANFAATAN TANAH PEKARANGAN RT.docx', '', NULL),
(39, '2024-01-24', 777, 'pengajuan berkas', 'silvi', 'nia', 'DATA PERMANFAATAN TANAH PEKARANGAN RT.06 RW.10.docx', '', NULL),
(40, '2024-01-24', 7112, 'pengajuan dana', 'papi', 'mami', 'DATA PERMANFAATAN TANAH PEKARANGAN RT.06 RW.10.docx', '', NULL),
(41, '2024-01-24', 112, 'pengajuan dana', 'kapolda', 'renmin', 'Surat Tanda Terima PT NIAGA JAYA.pdf', '', NULL),
(42, '2024-01-17', 112, 'pengajuan dana', 'kapolda', 'renmin', 'Surat Tanda Terima PT NIAGA JAYA.pdf', '', NULL),
(43, '2024-01-25', 112, 'pengajuan dana', 'kapolda', 'renmin', 'Surat Tanda Terima PT NIAGA JAYA.pdf', '', NULL),
(58, '2024-02-10', 9876, 'tidak tahu', 'kapolda', 'siapa saja', 'Surat Tanda Terima PT NIAGA JAYA.pdf', 'PENDING', 'erosalfedo1@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id_operator` int(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `operator`
--

CREATE TABLE `operator` (
  `id_operator` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `jabatan` varchar(255) NOT NULL,
  `subbag` varchar(255) NOT NULL,
  `role` enum('admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `operator`
--

INSERT INTO `operator` (`id_operator`, `username`, `password`, `jabatan`, `subbag`, `role`) VALUES
(1, 'harun@gmail.com', '123', 'bint', 'dad', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `jabatan` varchar(255) NOT NULL,
  `subbag` varchar(255) NOT NULL,
  `role` enum('user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `nama`, `password`, `jabatan`, `subbag`, `role`) VALUES
(2, 'syifa@gmail.com', 'Syifa', '123', 'bint', 'dad', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `view`
--

CREATE TABLE `view` (
  `tanggal` date NOT NULL,
  `nomor` int(11) NOT NULL,
  `perihal` varchar(50) NOT NULL,
  `dari` varchar(50) NOT NULL,
  `kepada` varchar(50) NOT NULL,
  `file` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `input_file`
--
ALTER TABLE `input_file`
  ADD PRIMARY KEY (`kode_file`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD KEY `id_operator` (`id_operator`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `operator`
--
ALTER TABLE `operator`
  ADD PRIMARY KEY (`id_operator`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `input_file`
--
ALTER TABLE `input_file`
  MODIFY `kode_file` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `operator`
--
ALTER TABLE `operator`
  MODIFY `id_operator` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `login`
--
ALTER TABLE `login`
  ADD CONSTRAINT `login_ibfk_1` FOREIGN KEY (`id_operator`) REFERENCES `operator` (`id_operator`),
  ADD CONSTRAINT `login_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
